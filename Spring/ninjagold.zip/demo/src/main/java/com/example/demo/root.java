package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

@Controller
public class root {
    @RequestMapping(value="/")
    public String root(HttpSession session,Model model) {
        if (session.isNew()) {
            session.setAttribute("money",0);
            session.setAttribute("text","");

             }
        return "root.jsp";
    }

    @RequestMapping(value="/process")
    public String process(HttpSession session,Model model) {
        if (session.isNew()) {
            session.setAttribute("money",0);
            session.setAttribute("text","");

        }
        return "root.jsp";
    }

    @RequestMapping(value="/process_money", method=RequestMethod.POST)
    public String process_money(@RequestParam(value="type") String type ,HttpSession session) {
       int val=0;
       int ch;
       String action="earned";
       String msg = "";

       Random ran = new Random();
        // Print next int value
        // Returns number between 0-9
        if (type.equals("farm")){
            val =ran.nextInt(11)+10;
//            money= (Integer) session.getAttribute("mondey");
//            money+=val;
//            session.setAttribute("money",money);

            session.setAttribute("money",(Integer) session.getAttribute("money")+val);
        }
        else if (type.equals("cave")){
            val =ran.nextInt(6)+5;

            session.setAttribute("money",(Integer) session.getAttribute("money")+val);
        }
        else if (type.equals("house")){
            val =ran.nextInt(4)+2;

            session.setAttribute("money",(Integer) session.getAttribute("money")+val);


        }
        else if (type.equals("casino")) {
            val = ran.nextInt(51);
            ch = ran.nextInt(2);
            if (ch == 0) {
                action = "earned";

                session.setAttribute("money", (Integer) session.getAttribute("money") + val);

            }
            if (ch == 1) {
                action = "lost";

                session.setAttribute("money", (Integer) session.getAttribute("money") - val);

            }

        }

        String datePattern = "MMMM DD yyyy h:mm a";
        SimpleDateFormat dateFormat = new SimpleDateFormat(datePattern);
        String date = dateFormat.format(new Date());
            if (action.equals("earned")){
            msg=action+" "+val+" golds from the type "+type+" "+date+"\n";
            }

            else if (action.equals("lost")){
            msg ="Entered a "+type+" and "+action+val+" golds .. Ouch"+" "+date+"\n";

            }
            session.setAttribute("text",(String)session.getAttribute("text")+msg);
            session.setAttribute("action",action);

            return "redirect:/";

        }


    @RequestMapping(value="/restart")
    public String restart(HttpSession session) {
        if (!session.isNew()) {
            session.invalidate();
        }

    return "redirect:/";
    }

}