function alertPage() {
    alert(`The time page was loaded`);
}

