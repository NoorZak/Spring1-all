function alertPage() {
    alert(`The date page was loaded`);
}

